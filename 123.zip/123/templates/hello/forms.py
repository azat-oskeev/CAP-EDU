from django import forms

class UserForm(forms.Form):
    name = forms.CharField(help_text='Enter your name', required=False)
    age = forms.IntegerField(label='Возраст', required=False)
    email = forms.EmailField(label='Email', required=False)
    date = forms.DateField(label='Дата рождения', required=False)
    
    field_order = ['age', 'name', 'date', 'email']