from django.db import models

class Task(models.Model):
    title = models.CharField(max_length=200)  # Название задачи
    description = models.TextField(blank=True)  # Описание задачи (необязательно)
    complete = models.BooleanField(default=False)  # Статус выполнения
    created = models.DateTimeField(auto_now_add=True)  # Дата создания

    def __str__(self):
        return self.title