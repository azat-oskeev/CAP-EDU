from django.urls import path
from hello.views import user_profile_view, hello_view
from . import views
from django.urls import path, include

urlpatterns = [
    path('', hello_view),
    path('user/<str:username>/', user_profile_view),
    
]


urlpatterns = [
    path('products/', include('hello.urls')),  
]

from django.urls import path
from . import views

urlpatterns = [
    path('', views.set_cookie_view, name='product_list'),             
    path('<int:id>/top/', views.product_top, name='product_top'),   
    path('new/', views.user_profile_view, name='new_products'),         
]