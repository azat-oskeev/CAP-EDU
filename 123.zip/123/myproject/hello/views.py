from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def hello_view(request):
    return HttpResponse("Hello Cap Education")
def request_info_view(request):
    method = request.method  # Получение метода запроса
    path = request.path      # Получение пути URL
    user_agent = request.headers.get('User-Agent')  # Получение заголовка User-Agent
    host = request.get_host()  # Получение хоста

    response_content = f"Метод: {method}, Путь: {path}, Браузер: {user_agent}, Хост: {host}"
    return HttpResponse(response_content)

def simple_response_view(request):
    return HttpResponse("Привет, это простой ответ!", content_type="text/plain")

def custom_headers_view(request):
    response = HttpResponse("Секретный код отправлен", content_type="text/plain")
    response['Secret-Code'] = '123ABC'
    return response

def user_profile_view(request, username):
    return HttpResponse(f"Профиль пользователя: {username}")

from django.http import HttpResponse

def product_top(request, id):
    return HttpResponse(f"Топовые характеристики товара с ID: {id}")

from django.shortcuts import redirect

def redirect_to_about(request):
    return redirect('/about/')  # Временная переадресация на страницу "О нас"

from django.http import HttpResponseNotFound

def page_not_found(request):
    return HttpResponseNotFound("Страница не найдена")

from django.http import JsonResponse

def json_response_view(request):
    data = {'name': 'John', 'age': 25}
    return JsonResponse(data)

from django.http import HttpResponse

def set_cookie_view(request):
    response = HttpResponse("Cookie установлена")
    response.set_cookie('user_id', '12345', max_age=3600)  # Cookie будет действовать 1 час
    return response

def get_cookie_view(request):
    user_id = request.COOKIES.get('user_id', 'Неизвестный пользователь')
    return HttpResponse(f"ID пользователя: {user_id}")

