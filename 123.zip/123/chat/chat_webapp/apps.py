from django.apps import AppConfig


class ChatWebappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chat_webapp'
