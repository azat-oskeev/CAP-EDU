from zipfile import ZipFile, ZIP_DEFLATED

with ZipFile ("Capeducation.zip",'a' ,compression=ZIP_DEFLATED,compresslevel=3) as myzip:
    myzip.write("main.py","main2.py")